### 项目结构
```
计网课设代码
...
├──constants.py 公共常量模块
├──page.py UI界面模块
│  └──Application UI界面类
├──control.py 报文捕获线程控制模块
├──tools.py 工具模块
├──analysis.py 数据报分析模块
└──main.py 主程序入口
```
### 命名规范
![命名规范](https://github.com/483170596/WebsiteCourseDesign/blob/main/%E5%9B%BE%E7%89%87/%E5%91%BD%E5%90%8D%E8%A7%84%E8%8C%83.png?raw=true)

