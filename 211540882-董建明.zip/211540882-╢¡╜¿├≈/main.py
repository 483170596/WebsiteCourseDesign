from page import Application

app = Application()
app.mainloop()
